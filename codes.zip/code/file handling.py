
##Syntax  to open the file
f = open(filename, mode)




file=open("C:\\Users\\nraje\\OneDrive\\Desktop\\python.txt","r+")
file.readlines()

file.writelines("\nPresently Im learning")



with open("C:\\Users\\nraje\\OneDrive\\Desktop\\python.txt","r+") as File:
    data=File.read()
data
##Write Mode
file=open("C:\\Users\\nraje\\OneDrive\\Desktop\\python.txt","a")
file.writelines("Hello world")


##Append Mode





# Python code to illustrate split() function
with open("C:\\Users\\nraje\\OneDrive\\Desktop\\python.txt", "r") as file:
	data = file.readlines()
    data
	for line in data:
		word = line.split()
print (word[::-1])
