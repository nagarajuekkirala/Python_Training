# -*- coding: utf-8 -*-
"""
Created on Wed Dec 28 12:06:21 2022

@author: nraje
"""
a=4
b=2
if a>b: 
print(a)    
