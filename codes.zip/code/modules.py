# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 12:28:06 2023

@author: nraje
"""
import math
dir(math)
pi
floor(4.7)
ceil(4.7)
sqrt(144)
cos(360)
log10(10)
exp(9)
pow(12,8)


import random as rd
dir(random)
num=rd.randint(0, 20)











#Directive	Description	Example	Try it
#  %a	Weekday, short version	Wed	
# %A	Weekday, full version	Wednesday	
# %w	Weekday as a number 0-6, 0 is Sunday	3	
# %d	Day of month 01-31	31	
# %b	Month name, short version	Dec	
# %B	Month name, full version	December	
# %m	Month as a number 01-12	12	
# %y	Year, short version, without century	18	
# %Y	Year, full version	2018	
# %H	Hour 00-23	17	
# %I	Hour 00-12	05	
# %p	AM/PM	PM	
# %M	Minute 00-59	41	
# %S	Second 00-59	08	
# %f	Microsecond 000000-999999	548513	
# %Z	Timezone	CST	
# %j	Day number of year 001-366	365	
# %U	Week number of year, Sunday as the first day of week, 00-53	52	
# %W	Week number of year, Monday as the first day of week, 00-53	52	
# %c	Local version of date and time	Mon Dec 31 17:41:00 2018	
# %C	Century	20	
# %x	Local version of date	12/31/18	
# %X	Local version of time	17:41:00	
# %%	A % character	%	
# %G	ISO 8601 year	2018	
# %u	ISO 8601 weekday (1-7)	1	
# %V	ISO 8601 weeknumber (01-53)	01










import


















###RAndom module




#seed()	Initialize the random number generator
#getstate()	Returns the current internal state of the random number generator
#setstate()	Restores the internal state of the random number generator
#getrandbits()	Returns a number representing the random bits
#randrange()	Returns a random number between the given range
#randint()	Returns a random number between the given range
#choice()	Returns a random element from the given sequence
#choices()	Returns a list with a random selection from the given sequence
#shuffle()	Takes a sequence and returns the sequence in a random order
#sample()	Returns a given sample of a sequence
#random()	Returns a random float number between 0 and 1
#uniform()	Returns a random float number between two given parameters
#triangular()	Returns a random float number between two given parameters, you can also set a mode parameter to specify the midpoint between the two other parameters
#betavariate()	Returns a random float number between 0 and 1 based on the Beta distribution (used in statistics)
#expovariate()	Returns a random float number based on the Exponential distribution (used in statistics)
#gammavariate()	Returns a random float number based on the Gamma distribution (used in statistics)
#gauss()	Returns a random float number based on the Gaussian distribution (used in probability theories)
#lognormvariate()	Returns a random float number based on a log-normal distribution (used in probability theories)
#normalvariate()	Returns a random float number based on the normal distribution (used in probability theories)
#vonmisesvariate()	Returns a random float number based on the von Mises distribution (used in directional statistics)
#paretovariate()	Returns a random float number based on the Pareto distribution (used in probability theories)
#weibullvariate()	Returns a random float number based on the Weibull distribution (used in statistics)