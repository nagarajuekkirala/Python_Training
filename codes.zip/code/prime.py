# -*- coding: utf-8 -*-
"""
Created on Thu Dec 29 16:16:45 2022

@author: nraje
"""

prime=[]
for num in range(1,100):
    if num == 1:
        print(num, "is not a prime number")
    elif num > 1:
        for i in range(2,num):
            if (num % i) == 0:
                break
        else:
            print(num)
