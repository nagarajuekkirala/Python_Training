# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 09:31:56 2023

@author: nraje
"""



###  global variables and local variables
b=45
a=67
def add(a,b):
    a=10
    return a+b

add(a,b)


def sub(x,y):
    x=200
    y=100
    return x-y
sub(x=20,y=10)





#####   Recursive functions

def fact(n):
    if n==0:
        result=1
    elif n<0:
        result="ENter valid positive number"
    elif n>0:
        result=n*fact(n-1)
    return result


fact(-3)






### Lambda Functions

value=lambda n:n**2
value(6)


def raj(a, b):
    return a/b

raj(10,40)





name=lambda a,b:a/b
name(100,140)




##############   Filter function   ###################

def isEven(x):
    if x%2==0: 
        return True
    else: 
        return False
    
l=[0,5,10,15,20,25,30] 
l1=list(filter(isEven,l))
print(l1) 


## With lambda function
l=[0,5,4,7,10,125,120,2,3]
l1=tuple(filter(lambda x:x%2==1,l)) 
print(l1) #[0,10,20,30] 


l2=list(filter(lambda x:x%2!=0,l))
print(l2) #[5,15,25]



###########     map() #############
li=(1,2,3,4,5)
def trippleIt(x):
    return 3*x 
l4=list(map(trippleIt,li))
print(l4)

## With Lambda
l=[1,2,3,4,5]
l1=list(map(lambda x:4*x,l))
print(l1)

## alternative
l2=[]
for i in l:
    l2.append(i*4)
print(l2)


###########   reduce() ######################


from functools import * 

l=[10,20,30,40,50]
result=reduce(lambda x,y:x*y,l)
print(result) # 150
