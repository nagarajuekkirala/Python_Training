# -*- coding: utf-8 -*-
"""
Created on Tue Dec 27 19:10:11 2022

@author: nraje
"""
###T######   Type conversion      #####

#### Numerical ######
##Int
a=10
b=float(a)
c=complex(a)
d=bool(a)
e=str(a)
print(e)

type(a)
type(b)
print(c)
type(c)
type(d)
type(e)



### Float

f=10.5
type(f)

g=int(f)
h=complex(f)
type(h)

i=str(f)
print(i)
j=bool(f)
print(j)


### Complex
k=10+5j
print(k)
type(k)

int(k)
float(k)
bool(k)
str(k)


### bool
t=False
print(t)
type(t)

int(t)
float(t)
complex(t)
str(t)




### Collection Data type
v=[1,"Hello",2.6]
print(v)
type(v)


tuple(v)
set(v)
dict(v)
frozenset(v)



n=(1,3,5,7,8)
print(n)
type(n)

list(n)
set(n)
dict(n)
frozenset(n)



r={1,3,44,6,89}
type(r)
print(r)



list(r)
tuple(r)
frozenset(r)



roll_no=(1,1,2,3,4,4,5,6,7)
a=list(roll_no)
a.append(8)
a.append(9)
a.append(10)
a
set(a)


b=set(roll_no)
b
b.add(8)
b.add(9)
b.add(10)
print(b)


roll_no.append(8,9,10)
set(roll_no)




list.append(8,9,10)
ro

a=10
b=20
c=a+b
print("The sum of two numbers is :",c)
print(f"the sum {a} and b is : {c}")

the sum of 10 and 20 is : 30


age=20
height=166 
weight=60


print(f"Hello Mahesh your age is  {age} years and height is {height} cm and weight is{weight} kg")



a=input("enter your name:  ")










