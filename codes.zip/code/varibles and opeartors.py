# -*- coding: utf-8 -*-
"""
Created on Wed Dec 21 20:28:21 2022

@author: nraje
"""

######################### Python Indentifiers #######################

########### Valid Indetifiers   ##########
var1=23
print(var1) 


var_1="Hello World"
print(var_1)

NAME=45
print(NAME)

nam2e="Python"
print(nam2e)

__peg_parser_=6
print(__peg_parser_)

list=10
print(list)
 
list=10
print(list)
############    Invalid Identifers    ###############

1var=10
print(1var)

var@ible="Hai"
print(var@ible)

def=110
print(def)

##### What are Keywords in Python
import keyword
print(keyword.kwlist)
print(len(keyword.kwlist))


#################   Operators   ##########################

# Arithematic
number1=11
number2=5
print(number1 + number2)     # add 
print(number1-number2)      # sub
print(number1 *number2)     # Mul
print(number1 / number2)    # division
print(number1 // number2)   # floor division(quotient)
print(number1 % number2)    # Moduluas(remainder)
print(number1 ** number2)   # power of





## Comparision (Relational ) operator #####

a = 5

b = 2
# equal to operator
print( a==b )

# not equal to operator
print( a != b)

# greater than operator
print( a > b)

# less than operator
print( a < b)

# greater than or equal to operator
print(a >= b)

# less than or equal to operator
print(a <= b)


###### Logical Operators  ########
# logical AND
print(True and True)     
print(True and False)  
print(bool(" "))  

# logical OR
print(True or False)     

# logical NOT
print(not True)          

print(10 and 5)     
print(0 and 10)    

# logical OR
print(1100 or 17)     

# logical NOT
print(not 1)
print(not 0)



#########    Bitwise Operators   ############

A = 10 
B = 11

print(A & B )
print(A | B )
print(A ^ B )
print(A << 1)
print(B << 1)


######### Special Operators  ##############
#### Identity Opearators
a=10
b=20
print(a is b)
print(a is not b)

#### Membership Opearators
class1=["Ramesh","Suresh","Mahesh"]

"Ramesh" in class1
"Paramesh" in class1
"Suresh" not in class1

##### Priority Order
a=30 
b=20 
c=10 
d=5 
print((a+b)*c/d)  
print(a+(b*c)/d) 




